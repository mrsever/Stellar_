const StellarSdk = require('stellar-sdk');
const server = new StellarSdk.Server('https://horizon-testnet.stellar.org');

const getTransactionHistory = async (publicKey) => {
  const transactions = await server.transactions()
    .forAccount(publicKey)
    .order('desc')
    .call();

  return transactions.records.map(tx => ({
    id: tx.id,
    createdAt: tx.created_at,
    memo: tx.memo_type === 'text' ? tx.memo : null
  }));
};

module.exports = {
  getTransactionHistory
};
