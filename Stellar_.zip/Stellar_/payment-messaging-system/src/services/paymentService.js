const StellarSdk = require('stellar-sdk');
const server = new StellarSdk.Server('https://horizon-testnet.stellar.org');
const sourceKeys = StellarSdk.Keypair.fromSecret('YOUR_SECRET_KEY');

const sendPayment = async (destinationId, amount, message) => {
  const sourceAccount = await server.loadAccount(sourceKeys.publicKey());

  const transaction = new StellarSdk.TransactionBuilder(sourceAccount, {
    fee: StellarSdk.BASE_FEE,
    networkPassphrase: StellarSdk.Networks.TESTNET
  })
    .addOperation(StellarSdk.Operation.payment({
      destination: destinationId,
      asset: StellarSdk.Asset.native(),
      amount: amount
    }))
    .addMemo(StellarSdk.Memo.text(message))
    .setTimeout(30)
    .build();

  transaction.sign(sourceKeys);

  return server.submitTransaction(transaction);
};

const getBalance = async (publicKey) => {
  const account = await server.loadAccount(publicKey);
  return account.balances.find(balance => balance.asset_type === 'native').balance;
};

module.exports = {
  sendPayment,
  getBalance
};
