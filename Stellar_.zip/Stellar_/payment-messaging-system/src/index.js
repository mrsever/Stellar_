const paymentService = require('./services/paymentService');
const messageService = require('./services/messageService');

// Örnek işlemler
(async () => {
  try {
    const balance = await paymentService.getBalance('YOUR_PUBLIC_KEY');
    console.log('Balance:', balance);

    const result = await paymentService.sendPayment('DESTINATION_PUBLIC_KEY', '10', 'Test payment');
    console.log('Payment Result:', result);

    const history = await messageService.getTransactionHistory('YOUR_PUBLIC_KEY');
    console.log('Transaction History:', history);
  } catch (error) {
    console.error('Error:', error);
  }
})();
